/**
 * 主入口文件
 * 页面加载完成后初始化地图和相关功能
 */

// 页面加载完成后初始化地图
document.addEventListener('DOMContentLoaded', function() {
    initMap();
    
    // 预加载图层列表（在后台加载，不阻塞页面）
    fetchLayersFromGeoServer('WebGIS').then(layers => {
        console.log('图层列表预加载完成，共', layers.length, '个图层');
    }).catch(err => {
        console.log('图层列表预加载失败，将在打开设置面板时使用预定义列表');
    });
    
    // 加载所有标注
    loadMarkersFromDatabase().then(markers => {
        console.log('标注加载完成，共', markers.length, '个标注');
    });
});

